import React from 'react'

function Bookings() {
  return (
    <div className='bookings'>
        <h1>Bookings</h1>
        </div>
  )
}

export default Bookings;