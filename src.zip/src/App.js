import React from 'react';
import './App.css';
import Navbar from './components/Navbar';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Reports from './pages/Reports';
import Services from './pages/Services';
import Bookings from './pages/Bookings';
import Users from './pages/Users';
import Support from './pages/Support';


function App() {
  return (
    <>
        <Router>
        <Navbar/>
        <Routes>
          <Route path='/' exact element= {<Home/>} />
          <Route path='/reports' element= {<Reports/>} />
          <Route path='/services' element= {<Services/>} />
          <Route path='/bookings' element= {<Bookings/>} />
          <Route path='/users' element= {<Users/>} />
          <Route path='/support' element= {<Support/>} />
        </Routes>
      </Router>
    </>
  );
}

export default App;